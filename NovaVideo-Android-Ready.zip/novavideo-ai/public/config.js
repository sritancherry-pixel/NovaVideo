// Set this to your deployed NovaVideo backend URL for the Android APK.
// Example: window.NOVAVIDEO_API_BASE = "https://your-server.example.com";
window.NOVAVIDEO_API_BASE = "";
